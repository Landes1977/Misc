import org.apache.spark.sql.functions.udf


// Promotes base Scala array intersection to Spark column method
  spark.
    udf.
    register("array_intersect", (xs: Seq[String], ys: Seq[String]) => xs.intersect(ys))


// Promotes base Scala string contains to Spark column method
  spark.
    udf.
    register("Contains", (xs: String, ys: String) => (xs.contains(ys)))





 spark.sql(" SELECT * FROM ccv_selections.coe_hdr ").
    withColumn("BeneSexCd", when($"BeneSexCd" === "M", "M").
      otherwise(when($"BeneSexCd" === "F", "F").
      otherwise("U"))).
    withColumn("ComplexityBucket", when($"ComplicationDRG" === "WITH MCC" && $"MCCCount" <= 1, "MCC-1").
      otherwise(when($"ComplicationDRG" === "WITH MCC" && $"MCCCount" === 2, "MCC-2").
      otherwise(when($"ComplicationDRG" === "WITH MCC" && $"MCCCount" >= 3, "MCC-3+").
      otherwise(when($"ComplicationDRG" === "WITH CC" && $"CCCount" <= 1, "CC-1").
      otherwise(when($"ComplicationDRG" === "WITH CC" && $"CCCount" === 2, "CC-2").
      otherwise(when($"ComplicationDRG" === "WITH CC" && $"CCCount" > 2, "CC-3+").
      otherwise(when($"ComplicationDRG" === "WITHOUT MCC", "NoMCC").
      otherwise("Other")))))))).
// https://www.ncdc.noaa.gov/monitoring-references/maps/us-climate-regions.php
    withColumn("ClimateRegion", when($"ProvStCd".isNull, "Other").
      otherwise(when(size(callUDF("array_intersect", split($"ProvStCd", ","), lit(Array("IL", "IN", "KY", "MO", "OH", "TN", "WV")))) > 0, "Central").
      otherwise(when(size(callUDF("array_intersect", split($"ProvStCd", ","), lit(Array("IA", "MI", "MN", "WI")))) > 0, "EastNorthCentral").
      otherwise(when(size(callUDF("array_intersect", split($"ProvStCd", ","), lit(Array("CT", "DE", "ME", "MD", "MA", "NH", "NJ", "NY", "PA", "RI", "VT")))) > 0, "Northeast").
      otherwise(when(size(callUDF("array_intersect", split($"ProvStCd", ","), lit(Array("ID", "OR", "WA")))) > 0, "Northwest").
      otherwise(when(size(callUDF("array_intersect", split($"ProvStCd", ","), lit(Array("AR", "KS", "LA", "MS", "OK", "TX")))) > 0, "South").
      otherwise(when(size(callUDF("array_intersect", split($"ProvStCd", ","), lit(Array("AL", "FL", "GA", "NC", "SC", "VA")))) > 0, "Southeast").
      otherwise(when(size(callUDF("array_intersect", split($"ProvStCd", ","), lit(Array("AZ", "CO", "NM", "UT")))) > 0, "Southwest").
      otherwise(when(size(callUDF("array_intersect", split($"ProvStCd", ","), lit(Array("CA", "NV")))) > 0, "West").
      otherwise(when(size(callUDF("array_intersect", split($"ProvStCd", ","), lit(Array("MT", "NE", "ND", "SD", "WY")))) > 0, "WestNorthCentral").
      otherwise("Other"))))))))))).
    withColumn("DiagCdHoriz", split($"DiagCdHoriz", ", ")).
    withColumn("Sepsis", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("A4189", "A419")))) > 0, "UnspecifiedSepsis").
      otherwise(when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("A391", "A392", "A393", "A394", "A3989", "A399")))) > 0, "Meningococcal").
      otherwise(when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("A400", "A401", "A403", "A408", "A409")))) > 0, "Streptococcal").
      otherwise(when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("A4101", "A4102", "A411", "A412")))) > 0, "Staphylococcal").
      otherwise(when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("A4150", "A4151", "A4152", "A4153", "A4159")))) > 0, "Gram-negative").
      otherwise(when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("B007", "B377")))) > 0, "Herpes/Candidal").
      otherwise(when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("R571", "R578", "R6520", "R6521", "R7881")))) > 0, "Herpes/Candidal").
      otherwise(when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("A021", "A207", "A227", "A267", "A327", "A413", "A414", "A4181", "A427", "A5486")))) > 0, "Sepsis").
      otherwise("NoSepsis"))))))))).
    withColumn("CardiacArrest", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("I462", "I468", "I469")))) > 0, "Yes").
      otherwise("No")).
    withColumn("CysticFibrosis", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("E840", "E8411")))) > 0, "Yes").
      otherwise("No")).
    withColumn("NontraumaticSubarachnoidHemorrhage", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("I6000", "I6001", "I6002", "I6010", "I6011", "I6012", "I602", "I6030", "I6031", 
                                                                                                                    "I6032", "I604", "I6050", "I6051", "I6052", "I606", "I607", "I608", "I609")))) > 0, "Yes").
      otherwise("No")).
    withColumn("NontraumaticIntracerebralHemorrhage", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("I610", "I611", "I612", "I613", "I614", "I615", "I616", "I618", "I619")))) > 0, "Yes").
      otherwise("No")).
    withColumn("UnspecifiedNontraumaticIntracranial", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("I6200", "I6201", "I6202", "I6203", "I621")))) > 0, "Yes").
      otherwise("No")).
    withColumn("CerebralInfarctionThrombosis", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("I63", "I630", "I6300", "I6301", "I63011", "I63012", "I63013", "I63019", "I6302", "I6303", 
                                                                                                              "I63031", "I63032", "I63033", "I63039", "I6309", "I633", "I6330", "I6331", "I63311",
                                                                                                              "I63312", "I63313", "I63319", "I6332", "I63321", "I63322", "I63323", "I63329", "I6333", "I63331", 
                                                                                                              "I63332", "I63333", "I63339", "I6334", "I63341", "I63342", "I63343", "I63349", "I6339")))) > 0, "Yes").
      otherwise("No")).
    withColumn("CerebralInfarctionEmbolism", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("I631", "I6310", "I6311", "I63111", "I63112", "I63113", "I63119", "I6312", "I6313", "I63131", 
                                                                                                            "I63132", "I63133", "I63139", "I6319", "I634", "I6340", "I6341", "I63411", "I63412", "I63413", 
                                                                                                            "I63419", "I6342", "I63421", "I63422", "I63423", "I63429", "I6343", "I63431", "I63432", "I63433", 
                                                                                                            "I63439", "I6344", "I63441", "I63442", "I63443", "I63449", "I6349")))) > 0, "Yes").
      otherwise("No")).
    withColumn("CerebralInfarctionUnspecifiedOcclusionStenosis", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("I632", "I6320", "I6321", "I63211", "I63212", "I63213", "I63219", "I6322", "I6323", "I63231", 
                                                                                                                                "I63232", "I63233", "I63239", "I6329", "I635", "I6350", "I6351", "I63511", "I63512", "I63513",
                                                                                                                                "I63519", "I6352", "I63521", "I63522", "I63523", "I63529", "I6353", "I63531", "I63532",
                                                                                                                                "I63533", "I63539", "I6354", "I63541", "I63542", "I63543", "I63549", "I6359")))) > 0, "Yes").
      otherwise("No")).
    withColumn("CerebralInfarctionCerebralVenousThrombosis", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("I636")))) > 0, "Yes").
      otherwise("No")).
    withColumn("CerebralInfarctionOther", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("I6381", "I6389", "I639")))) > 0, "Yes").
      otherwise("No")).
    withColumn("ESRD", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("N186")))) > 0, "Yes").
      otherwise("No")).
    withColumn("SeverePreEclampsia", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("NO1412", "O1413")))) > 0, "Yes").
      otherwise("No")).
    withColumn("ChorioamnionitisFirstTrimester", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("O411210", "O411211", "O411212", "O411213", "O411214", "O411215", "O411219")))) > 0, "Yes").
      otherwise("No")).
    withColumn("ChorioamnionitisSecondTrimester", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("O411220", "O411221", "O411222", "O411223", "O411224", "O411225", "O411229")))) > 0, "Yes").
      otherwise("No")).
    withColumn("ChorioamnionitisThirdTrimester", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("O411230", "O411231", "O411232", "O411234", "O411235", "O411239")))) > 0, "Yes").
      otherwise("No")).
    withColumn("ChorioamnionitisUnspecified", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("O411290", "O411292", "O411293", "O411294", "O411295", "O411299")))) > 0, "Yes").
      otherwise("No")).
    withColumn("AcuteKidneyFailure", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("N170", "N171", "N172")))) > 0, "Yes").
      otherwise("No")).
    withColumn("IdiopathicAcutePancreatitis", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("K8500", "K8501", "K8502")))) > 0, "Yes").
      otherwise("No")).
    withColumn("IdiopathicAcutePancreatitis", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("K8500", "K8501", "K8502")))) > 0, "Yes").
      otherwise("No")).
    withColumn("BiliaryAcutePancreatitis", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("K8510", "K8511", "K8512")))) > 0, "Yes").
      otherwise("No")).
    withColumn("AlcoholAcutePancreatitis", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("K8520", "K8521", "K8522")))) > 0, "Yes").
      otherwise("No")).
    withColumn("DrugAcutePancreatitis", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("K8530", "K8531", "K8532")))) > 0, "Yes").
      otherwise("No")).
    withColumn("OtherAcutePancreatitis", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("K8580", "K8581", "K8582", "K8590", "K8591", "K8592")))) > 0, "Yes").
      otherwise("No")).
    withColumn("Encephalopathy", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("G92", "G9340", "G9341", "G9349")))) > 0, "Yes").
      otherwise("No")).
    withColumn("AcuteHeartFailure", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("I5021", "I5023", "I5031", "I5033", "I5041", "I5043")))) > 0, "Yes").
      otherwise("No")). 
    withColumn("Malnutrition", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("E40", "E41", "E42", "E43")))) > 0, "Yes").
      otherwise("No")).   
    withColumn("RespiratoryFailure", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("J951", "J952", "J953", "J95821", "J95822", "J9600", "J9601", 
                                                                                                    "J9602", "J9620", "J9621", "J9622", "J9690", "J9691", "J9692")))) > 0, "Yes").
      otherwise("No")).
    withColumn("Liver_Hepatitis", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("K7200", "K7201", "K7211", "K7291", "K762")))) > 0, "Yes").
      otherwise("No")).
    withColumn("MI", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("I2101", "I2102", "I2109", "I2111", "I2119", "I2121", "I2129", "I213", "I214", "I219", "I21A1", 
                                                                                    "I21A9", "I220", "I221", "I222", "I228", "I229")))) > 0, "Yes").
      otherwise("No")).
    withColumn("Ketoacidosis", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("E0810", "E0811", "E0910", "E0911", "E1010", "E1011", "E1110", "E1111", "E1310", "E1311")))) > 0, "Yes").
      otherwise("No")).
    withColumn("Shock", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("A483", "O751", "R570", "R571", "R578", "R6521", "T794XXA", "T8111XA", "T8112XA", "T8119XA")))) > 0, "Yes").
      otherwise("No")).
    withColumn("AIDS", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("B20")))) > 0, "Yes").
      otherwise("No")).
    withColumn("Pancytopenia", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("D61810", "D61811")))) > 0, "Yes").
      otherwise("No")).
    withColumn("CerebralEdema", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("G935", "G936")))) > 0, "Yes").
      otherwise("No")).
    withColumn("VaricellaPneumonia", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("B012")))) > 0, "Yes").
      otherwise("No")).
    withColumn("Influenza", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("J1000", "J1001", "J1008", "J1100", "J1108")))) > 0, "Yes").
      otherwise("No")).
    withColumn("ViralPneumonia", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("J120", "J121", "J122", "J123", "J1281", "J1289", "J129")))) > 0, "Yes").
      otherwise("No")).
    withColumn("StreptococcusPneumonia", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("J13")))) > 0, "Yes").
      otherwise("No")).
    withColumn("HemophilusPneumonia", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("J14")))) > 0, "Yes").
      otherwise("No")).
    withColumn("BacterialPneumonia", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("J150", "J151", "J1520", "J15211", "J15212", "J1529", "J153", "J154", "J155", "J156", "J157", "J158", "J159")))) > 0, "Yes").
      otherwise("No")).
    withColumn("OtherPneumonia", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("J160", "J168", "J17", "J180", "J181", "J188", "J189")))) > 0, "Yes").
      otherwise("No")).
    withColumn("AspirationPneumonia", when(size(callUDF("array_intersect", $"DiagCdHoriz", lit(Array("J690", "J691", "J698")))) > 0, "Yes").
      otherwise("No")).
    drop("DiagCdHoriz").
    withColumn("TimeToAdd", datediff($"AddedDt", $"ClmThruDt")).
    withColumn("AddTimeBucket", when($"TimeToAdd" <= 3*30.4375, "01-03Month").
      otherwise(when($"TimeToAdd" <= 6*30.4375, "04-06Month").
      otherwise(when($"TimeToAdd" <= 9*30.4375, "07-09Month").
      otherwise(when($"TimeToAdd" <= 12*30.4375, "10-12Month").
      otherwise(when($"TimeToAdd" <= 15*30.4375, "13-15Month").
      otherwise(when($"TimeToAdd" <= 18*30.4375, "16-18Month").
      otherwise(when($"TimeToAdd" <= 24*30.4375, "19-24Month").
      otherwise("Over24Month")))))))).
    withColumn("LOS", datediff($"ClmThruDt", $"ClmFromDt") + 1).
    drop("ClmThruDt", "AddedDt").
    withColumn("LOSBucket", when($"LOSAMFactor" < 1 && $"LOSGMFactor" < 1, "Low").
      otherwise(when((($"LOSAMFactor" > 1 && $"LOSGMFactor" < 1) || ($"LOSAMFactor" < 1 && $"LOSGMFactor" > 1)), "Middle").
      otherwise(when($"LOSAMFactor" > 1 && $"LOSGMFactor" > 1, "High").
      otherwise("Error")))).
    withColumn("Age", floor(datediff($"ClmFromDt", $"BeneBirthDt") / 365.25)).
    drop("ClmFromDt", "BeneBirthDt").
    withColumn("AgeBucket", when($"Age" <= 20, "00-20").
      otherwise(when($"Age" <= 25, "21-25").
      otherwise(when($"Age" <= 30, "26-30").
      otherwise(when($"Age" <= 35, "31-25").
      otherwise(when($"Age" <= 40, "36-40").
      otherwise(when($"Age" <= 45, "41-45").
      otherwise(when($"Age" <= 50, "46-50").
      otherwise(when($"Age" <= 55, "51-55").
      otherwise(when($"Age" <= 60, "56-60").
      otherwise(when($"Age" <= 65, "61-65").
      otherwise(when($"Age" <= 70, "66-70").
      otherwise(when($"Age" <= 75, "71-75").
      otherwise(when($"Age" <= 80, "76-80").
      otherwise(when($"Age" <= 85, "81-85").
      otherwise(when($"Age" <= 90, "86-90").
      otherwise(when($"Age" <= 95, "91-95").
      otherwise("Over95"))))))))))))))))).
    withColumn("DischargeGroup", when($"DischargeStatus" === "01" || 
                                      $"DischargeStatus" === "08" || 
                                      $"DischargeStatus" === "81", "Home").
      otherwise(when($"DischargeStatus" === "03" ||  
                     $"DischargeStatus" === "61" ||
                     $"DischargeStatus" === "64" || 
                     $"DischargeStatus" === "81" || 
                     $"DischargeStatus" === "89" ||
                     $"DischargeStatus" === "92" , "SNF").
      otherwise(when($"DischargeStatus" === "06" ||
                     $"DischargeStatus" === "86", "Home Health").
      otherwise(when($"DischargeStatus" === "50" || 
                     $"DischargeStatus" === "51", "Hospice")
      otherwise(when($"DischargeStatus" === "02" || 
                     $"DischargeStatus" === "05" || 
                     $"DischargeStatus" === "09" || 
                     $"DischargeStatus" === "62" || 
                     $"DischargeStatus" === "82" || 
                     $"DischargeStatus" === "90", "Inpatient").
      otherwise(when($"DischargeStatus" === "07", "LAMA").
      otherwise(when($"DischargeStatus" === "04", "ICF").
      otherwise(when($"DischargeStatus" === "43" || 
                     $"DischargeStatus" === "63" ||
                     $"DischargeStatus" === "66" ||                     
                     $"DischargeStatus" === "88" || 
                     $"DischargeStatus" === "91" ||
                     $"DischargeStatus" === "94", "Hospital").
      otherwise(when($"DischargeStatus" === "20" ||
                     $"DischargeStatus" === "41", "Expired").
      otherwise(when($"DischargeStatus" === "65" ||
                     $"DischargeStatus" === "93", "Psych").
      otherwise(when($"DischargeStatus" === "70" ||
                     $"DischargeStatus" === "95", "Not Defined").
      otherwise("Others")))))))))))).
    withColumn("AcuteRE", when($"DischargeStatus".cast("Int") > 80, 1).otherwise(0)).
    write.
    mode("Overwrite").
    parquet("/mldev/restricted/ml_ccv/mlworkspace/FL/CCV_COE_HDR_FL_ML")